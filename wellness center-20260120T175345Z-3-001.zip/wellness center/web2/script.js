// JavaScript for handling the "Book Your Appointment" button
document.getElementById("book-appointment-btn").addEventListener("click", function() {
    const form = document.getElementById("appointment-form");
    form.classList.toggle("hidden"); // Toggle the form visibility
});
